import java.awt.*;
import javax.swing.*;

public class RectangleFrame extends JFrame {
	public RectangleFrame() {
		Container contentPane= getContentPane();
        RectanglePanel panel = new RectanglePanel(); 
        contentPane.add(panel, BorderLayout.CENTER);
	}
	
    public static void main(String args[]) {
        RectangleFrame frame = new RectangleFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setVisible(true);
    }
}