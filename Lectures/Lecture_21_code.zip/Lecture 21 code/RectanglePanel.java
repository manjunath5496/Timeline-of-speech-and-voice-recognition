import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;     // For 2D classes

public class RectanglePanel extends JPanel {
    public void paintComponent(Graphics g) {
       super.paintComponent(g);
       Graphics2D g2= (Graphics2D) g;
       Rectangle2D rect= new Rectangle2D.Double(0, 0, 50, 100); 
       g2.setPaint(Color.RED);
       g2.draw(rect);
       
       g2.setPaint(Color.BLUE);
	   AffineTransform baseXf = new AffineTransform();
	   // Shift to the right 50 pixels, down 50 pixels
	   baseXf.translate(50,50);
	   g2.transform(baseXf); 
       g2.draw(rect);
    }
}