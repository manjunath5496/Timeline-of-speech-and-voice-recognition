import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ButtonPanel extends JPanel implements ActionListener {
    private int i= 0;
    private JLabel countLabel;
    private JButton countButton;
    
    public ButtonPanel() {
		// Create new JButton with prompt: �Show count�
		// Create new JLabel for output with text:�Count= 0�
		// Create new Font font1: Monospaced, Font.PLAIN, size 24
//        countLabel.setFont(font1);
//        countButton.setFont(font1);
		// Add your button to ButtonPanel (use add() method)
		// Add your label to ButtonPanel
		// Make the ButtonPanel object be the action listener
		// (We�re in the ButtonPanel constructor, so use this)  
    }
    public void actionPerformed(ActionEvent e) {
        i++;
        countLabel.setText("Count= " + i);
    }
}