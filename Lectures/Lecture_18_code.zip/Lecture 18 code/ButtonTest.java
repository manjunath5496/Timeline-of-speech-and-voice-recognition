import javax.swing.*;

public class ButtonTest {
	public static void main(String[] args) {
		// Create new frame
		// Set default close option
		// Show frame (set visible)
	}
}