import java.awt.*;
import javax.swing.*;

public class ButtonFrame extends JFrame {
	public ButtonFrame() {
		// Call superclass constructor with "Button Example"
		// Set size of frame
		// Get content pane
		// Create new panel (ButtonPanel, to be written next)
		// Add panel to content pane in BorderLayout.CENTER
	}
}