import java.awt.*;
import javax.swing.*;

public class ClockFrame extends JFrame{
	public ClockFrame() {
		super("Clock Test");		// or setTitle()
		setSize(300, 200);
		ClockPanel clock = new ClockPanel();
		Container contentPane= getContentPane();               
		contentPane.add(clock, BorderLayout.CENTER);       
	}

	public static void main(String[] args) {
		ClockFrame frame = new ClockFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}       
}