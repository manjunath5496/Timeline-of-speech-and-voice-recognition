
import javax.swing.*;import java.awt.*;

public class FlowLayoutExample
	extends JFrame
	{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FlowLayoutExample ex= new FlowLayoutExample();
		ex.setVisible( true );
	}
	
	public FlowLayoutExample( )
	{
		super( "FlowLayoutExample" );
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container pane= getContentPane();
		pane.setLayout( new FlowLayout() );
		JButton b1= new JButton( "Button1" );
		JButton b2= new JButton( "Button2" );
		JButton b3= new JButton( "Button3" );
		JButton b4= new JButton( "Button4" );
		JButton b5= new JButton( "Button5" );
		pane.add(b1);
		pane.add(b2);
		pane.add(b3);
		pane.add(b4);
		pane.add(b5);
		pack();
	}
}
