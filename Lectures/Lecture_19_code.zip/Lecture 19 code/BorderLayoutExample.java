
import javax.swing.*;import java.awt.*;

public class BorderLayoutExample
	extends JFrame
	{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BorderLayoutExample ex= new BorderLayoutExample();
		ex.setVisible( true );
	}
	
	public BorderLayoutExample( )
	{
		super( "BorderLayoutExample" );
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container pane= getContentPane();
		JButton b1= new JButton( "Button1" );
		JButton b2= new JButton( "Button2" );
		JButton b3= new JButton( "Button3" );
		JButton b4= new JButton( "Button4" );
		JButton b5= new JButton( "Button5" );
		pane.add(b1, BorderLayout.NORTH);
		pane.add(b2, BorderLayout.WEST);
		pane.add(b3, BorderLayout.CENTER);
		pane.add(b4, BorderLayout.EAST);
		pane.add(b5, BorderLayout.SOUTH);
		pack();
	}
}
