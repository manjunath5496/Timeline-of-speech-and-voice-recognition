import java.util.*;

public class PipeTest {
	public static void main(String[] args) {
		Pipe[] pipes= new Pipe[3];			// Array
		pipes[0]= new Pipe(0.25, 7);
		pipes[1]= new Pipe(0.15, 3);
		pipes[2]= new Pipe(0.27, 1);
		Arrays.sort(pipes);					// Built-in sort
		for (Pipe p: pipes)
			System.out.println(p);
		System.out.println();
		ArrayList<Pipe> pipes2= new ArrayList<Pipe>();
		pipes2.add(new Pipe(0.5, 4));
		pipes2.add(new Pipe(0.4, 5));
		pipes2.add(new Pipe(0.3, 8));
		Collections.sort(pipes2);			// Built-in sort
		for (Pipe p: pipes2)
			System.out.println(p);
	}
}