import java.util.*;

public class ExamComparatorDate implements Comparator<Exam> {
	public int compare(Exam a, Exam b) {
		if (a.getDate().compareTo(b.getDate()) < 0) 
			return -1;
		if (a.getDate().compareTo(b.getDate()) == 0)
			return 0;
		return 1;
	}
}