import java.util.*;

public class ExamComparatorRoom implements Comparator<Exam> {
	public int compare(Exam a, Exam b) {
		if (a.getRoom() < b.getRoom()) 
			return -1;
		if (a.getRoom() == b.getRoom())
			return 0;
		return 1;
	}
}