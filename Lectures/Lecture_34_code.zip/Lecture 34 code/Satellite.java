import java.util.*;

public class Satellite {
	/* Remove this comment, and one at the end (next to last line)
    private static class Experiment implements Comparable<Experiment> {
        private double ratio;
        private int weight;
        
        public Experiment(double r, int w) {
			ratio = r;
			weight = w;
		}
        
        public int compareTo(Experiment other) {
        	// Complete this method:
        }
        
        public String toString() {
			return (" Experiment: benefit: "+ (ratio*weight) + " weight: "+ weight+ " ratio: "+ ratio);
		}
    }
    
    public static void main(String[] args) {
        Experiment a= new Experiment(2.0, 2);
		Experiment b= new Experiment(1.5, 4);
		Experiment c= new Experiment(2.5, 2);
		Experiment d= new Experiment(1.66667, 3);
		Experiment[] e= {a, b, c, d};
		
		// Invoke a sort method

		// Set maximum weight= 7
		// Initialize cumulative weight, cumulative benefit= 0 

		// Loop thru the sorted experiments
		//   Accumulate the weight until the max weight is reached
		//   Accumulate the benefit as each experiment is added
		//     Compute benefit as ratio*weight
		//   Print out each experiment added to the payload
		//   Break out of the loop when max weight is reached

	   // Print the total benefit

    }
    */ // Remove this comment
}
