import java.util.*;

public class ExamComparatorSubject implements Comparator<Exam>{
	public int compare(Exam a, Exam b) {
		if (a.getSubject().compareTo(b.getSubject()) < 0) 
			return -1;
		if (a.getSubject().compareTo(b.getSubject()) == 0)
			return 0;
		return 1;
	}
}