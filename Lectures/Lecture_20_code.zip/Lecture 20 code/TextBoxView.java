import javax.swing.*;
import java.awt.*;

public class TextBoxView extends JPanel {
    private TextBoxModel model ;

    public TextBoxView( TextBoxModel m ) {
        model = m ;
    }

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2= (Graphics2D) g;
		double n= model.getNumber();
		double sq= model.getSqrt();
		g2.drawString("Square root of: " + n + " = " + sq, 20, 100);
	}
}