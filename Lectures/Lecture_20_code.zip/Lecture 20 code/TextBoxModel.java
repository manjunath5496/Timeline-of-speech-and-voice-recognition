public class TextBoxModel {
	private double number;
	public TextBoxModel() {};
	public void setNumber(double n) {
		number= n;
	}
	public double getNumber() {
		return number;
	}
	public double getSqrt() {
		return Math.sqrt(Math.abs(number));
	}
}