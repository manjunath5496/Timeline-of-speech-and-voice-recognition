import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;     // For 2D classes

public class TransformPanel extends JPanel {
    public void paintComponent(Graphics g) {
       super.paintComponent(g);
       Graphics2D g2= (Graphics2D) g;
       Rectangle2D rect= new Rectangle2D.Double(0, 0, 50, 100);
       
       g2.setPaint(Color.BLUE);
	   AffineTransform baseXf = new AffineTransform();
	   // Rotate by 18 degrees
	   baseXf.rotate(Math.PI/10.0);
	   baseXf.scale(2.0, 2.0);

	   g2.transform(baseXf); 
       g2.draw(rect);
    }
}