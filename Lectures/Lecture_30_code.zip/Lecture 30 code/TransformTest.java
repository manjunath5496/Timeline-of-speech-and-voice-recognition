import java.awt.*;

import javax.swing.*;

public class TransformTest {
    public static void main(String args[]) {
        JFrame frame = new JFrame("Rectangle transform");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        Container contentPane= frame.getContentPane();
        TransformPanel panel = new TransformPanel(); 
        contentPane.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}