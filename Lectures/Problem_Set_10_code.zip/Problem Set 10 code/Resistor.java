public class Resistor {
	int i;		// From node
	int j;		// To node
	double r;	// 1/resistance
	public Resistor(int i, int j, double r) {
		this.i = i;
		this.j = j;
		this.r = r;
	}
}