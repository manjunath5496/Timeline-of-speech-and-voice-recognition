import java.util.*;

public class GridTest {
	public static void main(String[] args) {
		double Vb= 12;		// Voltage of battery
		double Vext= 6;  //External Voltage
		// Intersection to connect battery
		int ib= 16;
		// Intersection to connect external voltage 
		int iext= 5;
		
		int n=18;			 	// Number of nodes in network, must be numbered 0 to n-1
		
		// resistors in network
		ArrayList<Resistor> resistors= new ArrayList<Resistor>();
		resistors.add(new Resistor(0, 1, 0.76));
		resistors.add(new Resistor(1, 2, 0.16));
		resistors.add(new Resistor(2, 3, 0.6));
		resistors.add(new Resistor(3, 4, 0.56));
		resistors.add(new Resistor(4, 5, 0.76));
		///
		resistors.add(new Resistor(6, 7, 0.76));
		resistors.add(new Resistor(7, 8, 0.16));
		resistors.add(new Resistor(8, 9, 0.6));
		resistors.add(new Resistor(9, 10, 0.56));
		resistors.add(new Resistor(10, 11, 0.76));
		///
		resistors.add(new Resistor(12, 13, 0.76));
		resistors.add(new Resistor(13, 14, 0.16));
		resistors.add(new Resistor(14, 15, 0.6));
		resistors.add(new Resistor(15, 16, 0.56));
		resistors.add(new Resistor(16, 17, 0.76));
		////
		resistors.add(new Resistor(0, 6, 0.76));
		resistors.add(new Resistor(1, 7, 0.16));
		resistors.add(new Resistor(2, 8, 0.6));
		resistors.add(new Resistor(3, 9, 0.56));
		resistors.add(new Resistor(4, 10, 0.76));
		resistors.add(new Resistor(5, 11, 0.99));
		////
		resistors.add(new Resistor(6, 12, 0.76));
		resistors.add(new Resistor(7, 13, 0.16));
		resistors.add(new Resistor(8, 14, 0.6));
		resistors.add(new Resistor(9, 15, 0.56));
		resistors.add(new Resistor(10, 16, 0.76));
		resistors.add(new Resistor(11, 17, 0.99));
		
		// You must complete main() 

	}
}