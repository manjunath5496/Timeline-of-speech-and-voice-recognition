public abstract class Vehicle {
	private int ID;
	protected double mass;
	protected double maxSpeed;
	protected String name;
	private static int nextID= 1;
	
	public Vehicle(double mass, double maxSpeed, String name) {
		ID++;
		this.mass = mass;
		this.maxSpeed = maxSpeed;
		this.name = name;
	}	
}