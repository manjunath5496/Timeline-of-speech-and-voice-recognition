public class ContinueTest {
	public static void main(String[] args) {
  		for (int i = 0; i < 6; i++) {
			if (i < 4)
				continue;	// Skip rest of loop
			System.out.println("i: "+i);
		}
		System.out.println("Done");
	}
}