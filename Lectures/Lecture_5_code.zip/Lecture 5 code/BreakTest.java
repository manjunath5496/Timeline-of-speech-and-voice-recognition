public class BreakTest {
	public static void main(String[] args) {
  		for (int i = 0; i < 6; i++) {
			if (i >= 3)
				break; 	// End loop
			System.out.println("i: "+i);
		}
		System.out.println("Done");
	}
}