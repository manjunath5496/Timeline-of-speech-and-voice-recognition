import java.util.*;

public class ListExample {
	public static void main(String[] args) {
		LinkedList<String> sensors= new LinkedList<String>();
		sensors.addFirst("light");
		sensors.addLast("touch");
		sensors.add("slider");		// Adds at end
		for (String s: sensors)
			System.out.println(s);
		System.out.println();
		sensors.remove(0);			// Remove at index 0
		sensors.remove("slider");
		for (String s: sensors)
			System.out.println(s);
	}
}