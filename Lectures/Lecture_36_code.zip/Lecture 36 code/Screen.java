
import java.awt.*;
import java.util.*;
import javax.swing.*;

public class Screen extends JPanel
{
    SLinkedListView dis;
    ListIterator iter;
    SLinkedList1 slist;
    Vector st;
    String drawMode;
    int a=50,b=60,extra=20,number,start,high,low,wid,iterF=0,ck=0;
    
    public Screen(SLinkedListView sview)
    {
        dis=sview;
        setBackground(Color.white);
        wid=sview.getWidth()/2+10;
    }
    
    public void setDrawMode(String s)
    {
        drawMode=s;
    }
    
    public void startIter(int n)
    {
        iterF=n;
    }
    
    public void resetK()
    {
        ck=0;
    }
    public void setK(int l)
    {
        ck=ck+l;
        if(ck==0)
            iterF=1;
    }
    
    public Object getFirst()
    {
        if ( slist.first == null )
            return null;
        else
            return slist.first.item;
    }
    
    public Object getLast()
    {
        if ( slist.last == null )
            return null;
        else
            return slist.last.item;
    }
    
    public void drawNumber(Graphics2D g2)
    {
        st=new Vector();
        slist=dis.getList();
        // int cou=slist.size();
        iter=slist.listIterator();
        
        while(iter.hasNext())
        {
            Object o=iter.next();
            st.addElement(o);
        }
        int cou=st.size();
        g2.setColor(Color.black);
        g2.setFont(new Font("Serif",Font.PLAIN,32));
        g2.drawString("List", 455,115);
        g2.drawString("first", 415,160);
        g2.drawString("last", 500,160);
        g2.drawRect(400,80,160,90);
        g2.drawLine(480,125,480,170);
        g2.drawLine(400,125,560,125);
        
        
        int position=wid-a-(cou-1)*(a+b)/2;
        g2.drawLine(440,170,position+40,243);
        drawArrow(g2,440,170,position+40,243);
        
        if(getFirst()==null)
        {
            g2.drawLine(440,170,position+(a+b)*cou+40,243);
            drawArrow(g2,440,170,position+(a+b)*cou+40,243);
        }
        else if(getFirst()==st.elementAt(0))
        {
            g2.drawLine(440,170,position+40,243);
            drawArrow(g2,440,170,position+40,243);
        }
        else
        {
            g2.drawLine(440,170,100+40,343);
            drawArrow(g2,440,170,100+40,343);
            g2.drawRect(100-5,343,90,45);
            g2.drawLine(100+40,343,100+40,388);
            g2.setFont(new Font("Serif", Font.BOLD,40));
            g2.drawString(new String("?"),100,380);
        }
        
        if(iterF==1)
        {
            g2.setColor(new Color(160,160,160));
            g2.drawLine(position-35,340,position-35,288);
            g2.drawLine(position-35,288,position-35+5,293);
            g2.drawLine(position-35,288,position-35-5,293);
        }
        
        
        int k=0;
        for(k=0; k<cou; k++)
        {
            g2.setColor(Color.black);
            g2.setFont(new Font("Serif", Font.BOLD,40));
            g2.drawRect(position-5,243,90,45);
            g2.drawLine(position+40,243,position+40,288);
            g2.drawLine(position+60,265,position+a+b-5,265);
            g2.drawLine(position+a+b-5,265,position+a+b-10,260);
            g2.drawLine(position+a+b-5,265,position+a+b-10,270);
            g2.drawString(st.elementAt(k).toString(),position,280);
            
            if(iterF==2 & ck-1==k)
            {
                g2.setColor(Color.green);
                g2.drawLine(position+40,340,position+40,288);
                g2.drawLine(position+40,288,position+40+5,293);
                g2.drawLine(position+40,288,position+40-5,293);
            }
            if(iterF==3 & ck-1==k)
            {
                g2.setColor(new Color(160,160,160));
                g2.drawLine(position+95,340,position+95,288);
                g2.drawLine(position+95,288,position+95+5,293);
                g2.drawLine(position+95,288,position+95-5,293);
            }
            
            position=position+a+b;
        }
        
        g2.setColor(Color.black);
        g2.setFont(new Font("Serif",Font.PLAIN,32));
        g2.drawString("null",position+5,272);
        
        if(getLast()==null)
        {
            g2.drawLine(520,170,position+40,243);
            drawArrow(g2,520,170,position+40,243);
        }
        else if(getLast()==st.elementAt(cou-1))
        {
            if(cou==0)
            {
                g2.drawLine(520,170,position+40,243);
                drawArrow(g2,520,170,position+40,243);
            }
            else
            {
                g2.drawLine(520,170,position-a-b+40,243);
                drawArrow(g2,520,170,position-a-b+40,243);
            }
        }
        else
        {
            g2.drawLine(520,170,100+40,343);
            drawArrow(g2,520,170,100+40,343);
            g2.drawRect(100-5,343,90,45);
            g2.drawLine(100+40,343,100+40,388);
            g2.setFont(new Font("Serif", Font.BOLD,40));
            g2.drawString(new String("?"),100,380);
        }
        
        
    }
    
    public void drawArrow(Graphics2D g2, int a1, int b1,int a2, int b2)
    {
        double x1=a1,y1=b1,x2=a2,y2=b2;
        double dx,dy;
        dy=Math.abs(Math.sqrt(30/(1+(((x2-x1)/(y2-y1))*((x2-x1)/(y2-y1))))));
        dx=Math.abs(((x2-x1)/(y2-y1))*dy);
        if(x1>x2)
        {
            double x3=x2+dx,y3=y2-dy;
            int x4=(int)(x3-dy),y4=(int)(y3-dx);
            int x5=(int)(x3+dy),y5=(int)(y3+dx);
            g2.drawLine((int)x2,(int)y2,x4,y4);
            g2.drawLine((int)x2,(int)y2,x5,y5);
        }
        else
        {
            double x3=x2-dx,y3=y2-dy;
            int x4=(int)(x3-dy),y4=(int)(y3+dx);
            g2.drawLine((int)x2,(int)y2,x4,y4);
            int x5=(int)(x3+dy),y5=(int)(y3-dx);
            g2.drawLine((int)x2,(int)y2,x5,y5);
        }
    }
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2=(Graphics2D)g;
        if(drawMode=="drawNumber")
            drawNumber(g2);
    }
}