import java.util.*;

public interface ListIterator {
    public boolean hasNext();
    public Object next()
        throws NoSuchElementException;
    public void remove()
        throws IllegalStateException;
    public void add( Object o );
    public void set( Object o )
        throws IllegalStateException;
}