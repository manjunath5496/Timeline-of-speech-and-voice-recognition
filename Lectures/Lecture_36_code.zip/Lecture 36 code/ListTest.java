import javax.swing.*;
import java.util.*;

public class ListTest {
	public static void main(String[] args) {
		SLinkedList1 a= new SLinkedList1();
		int n= 0;
		while (true) {
			String text= JOptionPane.showInputDialog("Enter 1-addFirst, 2-addLast, 3-add, 4-removeFirst, 5-removeLast, 6-contains, 7-quit: ");
			int action= Integer.parseInt(text);
			if (action == 7)
				break;
			if (action== 1 || action== 2  || action == 3)
				text= JOptionPane.showInputDialog("Enter string to store in list: ");
			if (action == 3) {
				String s= JOptionPane.showInputDialog("Enter position to store in list: ");
				n= Integer.parseInt(s);
			}
			if (action == 6)
				text= JOptionPane.showInputDialog("Enter string to find in list: ");
			try {
				if (action == 1)
					a.addFirst(text);
				else if (action == 2)
					a.addLast(text);
				else if (action == 3)
					a.add(n, text);
				else if (action == 4)
					a.removeFirst();
				else if (action== 5)
					a.removeLast();
				else
					System.out.println("List has " + text + "?: " + a.contains(text));
			} catch (NoSuchElementException e) {
				System.out.println("List is empty (exception caught)");
			}
			a.print();
		}
		System.exit(0);
	}
}