
public class SLinkedListApp    
{   
    public static void main( String[] args )
    {
        SLinkedListView view = new SLinkedListView();
    }    
}