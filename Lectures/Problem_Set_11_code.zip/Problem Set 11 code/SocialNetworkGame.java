import java.io.*;
import java.util.*;


public class SocialNetworkGame extends SLinkedList{		
		private String player;
		private String target;
		private float prize;
		private String fileName;
		
		private SLinkedList[] graph;
		private List<SLinkedList> contacts;
	
		
		public SocialNetworkGame(String pl,String tg,float pr,String fn){
		   	this.player = pl;
		   	this.target = tg;
		   	this.FileName = fn;
		   	this.prize = pr;
		}

public void setGraph(){
		// Read input file and call setGraph() to actually construct the graph (array of linked lists)
                //Complete Code here
}
	
public void setContacts() {
        //Starting with target at level 0 saves all the contacts of the different nodes until the player is found 
       	contacts = new ArrayList<SLinkedList>();
	SLinkedList allContacts = new SLinkedList();

       //Complete code here	
	
}
	
	
public static int findNameIndex(String name,int NumNodes,SLinkedList[] Graph) {
	// Go through every list: if it contains our name, gets the index of the name in graph
   
	//Complete Code
}	

    // Create other methods to perform the required taks.


 }
	
