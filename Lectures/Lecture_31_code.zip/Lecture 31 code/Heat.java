public class Heat {
    public static void main(String[] args) {
        double Te= 40.0, Tn=60.0, Tw=80.0, Ts=20.0;     // Edge temps
        int col= 4;
        int row= 4;
        int n= col * row;
        
        // Create a, matrix of coefficients
        Matrix a= new Matrix(n,n);
        for (int i=0; i < n; i++)
            for (int j=0; j < n; j++) {
                if (i==j)
                    a.setElement(i, j, 4.0);
                // else if (...)
                //  Complete this code: 
                //    Green elements (4, or ncols, away from diagonal)
                //    Blue elements (1 away from diagonal)
                //    Set blue and skip orange where we go to a point
                //    on the next row on the actual plate
       		  	//	  Relate i and j to determine blue, orange cells
       		  	//	  (e.g., is i == j + 1, for example?)
                else
                    a.setElement(i, j, 0.0);
            }
        System.out.println("A:");
        a.print();
        
        // Create b, matrix of knowns
        Matrix b= new Matrix(n, 1);
        for (int i=0; i < n; i++) {
            if (i < col)
                b.incrElement(i, 0, Tn);
            // if (...)
            // Complete this code for the other edges; no �elses�!
            //  Add edge temperature to b; you may add more than one
            //  Look at the Ax=b example slide to find the pattern
            //  Use i, col, row to determine cells at the edge
        }
        System.out.println("b:");
        b.print();
        
        Matrix x= Matrix.gaussian(a, b);
        System.out.println("Final x:");
        x.print();
        System.out.println("Temperature grid:");
		for (int i=0; i< row; i++) {
			for (int j=0; j < col; j++)
				System.out.print( Math.round(x.getElement((i*col+j),0))  + "  ");
			System.out.println();
		}
    }
}
