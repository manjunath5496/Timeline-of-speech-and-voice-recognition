public class Pathological {
	public static void main(String[] args) {
		double x= 3.13;
		double p= Math.PI;
		for (int i= 0; i < 40; i++) {
			double f= 3*x*x + 1.0/(p*p*p*p)*Math.log((p -x)*(p-x))+ 1;
			System.out.println("x: " + x + " f: " + f);
			x += 0.001;
		}
	}
}