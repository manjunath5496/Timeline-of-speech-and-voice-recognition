public class Quadratic implements MathFunction {
	public double f(double x) {
		return x*x - 2;
	}
}