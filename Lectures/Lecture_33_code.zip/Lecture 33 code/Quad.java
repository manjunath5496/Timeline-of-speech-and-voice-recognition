public class Quad implements MathFunctionNewton {
	public double fn(double x) {
		return x*x - 2;
	}

	public double fd(double x) {
		return 2*x;
	}
}