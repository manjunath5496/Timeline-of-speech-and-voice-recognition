public interface MathFunctionNewton {
	public double fn(double x);		// Function
	public double fd(double x);		// First derivative
}