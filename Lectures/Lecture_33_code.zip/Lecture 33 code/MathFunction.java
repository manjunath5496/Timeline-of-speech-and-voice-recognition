public interface MathFunction {
	public double f(double x);
}