import java.io.*;

public class SimpleReader {
    public static void main(String[] args) {
        try {
        	String eol = System.getProperty( "line.separator" );
            FileReader fin = new FileReader("TestIn.txt");
            BufferedReader b = new BufferedReader(fin);
            FileWriter fout = new FileWriter("TestOut.txt");
            BufferedWriter bout= new BufferedWriter(fout);
            
            String currentLine; 
            int i = 1;
            while ((currentLine = b.readLine()) != null) {
                bout.write((i++) + " " + currentLine + eol);}
            b.close();
            bout.close();
            System.out.println("Done");
        }
        catch (FileNotFoundException ef) {
            System.out.println("File not found");}
        catch (IOException ei) {
            System.out.println("IO Exception"); }
    }
}