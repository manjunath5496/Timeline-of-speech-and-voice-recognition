public class FullName implements Comparable<FullName> {
	private final String firstName;
	private final String lastName;

	public FullName( String f, String l ) {
		firstName= f;
		lastName= l;
	}

	public String getFirstName() {return firstName;}
	public String getLastName()  {return lastName;}

	public int compareTo( FullName fn ) {
		// Complete the  compareTo() method
		// Order by last name first
		return 0;		// Change this in your solution
	}

	public String toString() {
		return firstName + " " + lastName;
	}
}