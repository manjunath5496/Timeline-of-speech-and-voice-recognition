import java.util.*;
import javax.swing.*;

public class PhoneBook {
	public static void main(String[] args) {
		FullName scott= new FullName("Scott", "Stevens");
		FullName ellen= new FullName("Ellen", "Shipps");
		FullName pizza= new FullName("Mystic", "Pizza");
		FullName paul= new FullName("Paul", "Stevens");
		TreeMap<FullName,String> phones=
			new TreeMap<FullName,String>();
		phones.put(scott, "617-225-7178");
		phones.put(ellen, "781-646-2880");
		phones.put(pizza, "781-648-2000");
		phones.put(paul, "617-498-2142");
		
		while (true) {
			String text= JOptionPane.showInputDialog("Enter full name");
			if (text.isEmpty()) 
				break;
			// Your code here
			// Parse the full name (�firstName lastName�) using split(" ")
			// split() returns an array of Strings
			// Use the get() method with FullName1 key to retrieve
			//   the String phone number value.
			// Print out the phone number or �Subscriber unknown�
			//   if get() returns null
		}
	}
}