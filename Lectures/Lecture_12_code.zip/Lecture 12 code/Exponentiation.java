import javax.swing.*;

public class Exponentiation {
    public static void main(String[] args) {
        String input= JOptionPane.showInputDialog("Enter x");
        long x= Long.parseLong(input);
        input= JOptionPane.showInputDialog("Enter y");
        long y= Long.parseLong(input);
        long z= expResult(x, y);
        System.out.println(x + " to " + y + " power is: " + z);
        System.exit(0);
    }
    
    public static long expResult(long x, long y) {
        int result=0;		// Remove =0 if desired
        // Write code when y is small enough

        // Write code when we need to divide the problem further

        // Add System.out.println as desired to trace results
        
        return result;
    }
}