public class MaxRecurse2 {
	public static void main(String[] args) {
		int[] a= {35, 74, 32, 92, 53, 28, 50, 62};
		System.out.println("Main Max: " + max(0, 7, a));
	}
	
	public static int combine(int a, int b) {
		if (a >= b) return a;
		else return b;
	}
	
	public static int max( int i, int j, int[] arr) {
		System.out.println("Max(" + i + "," + j + ")");
		if ( (j - i) <= 1) {
			if (arr[j] >= arr[i]) {
				System.out.println("  " + arr[j]);
				return arr[j]; }
			else {
				System.out.println("  " + arr[i]);
				return arr[i]; } }
		else {
			int aa= (combine(max(i, (i+j)/2, arr), 
					max((i+j)/2+1, j, arr)));
			System.out.println("Max(" + i + "," + j + ")= " + aa);
			return aa;
		}
	}
}