import javax.swing.*;

public class Sequence3 {
	public static void main(String[] args) {
		String input = JOptionPane.showInputDialog("Enter n");
		int n = Integer.parseInt(input);
		System.out.println("i x y");
		for (int i = 1; i <= n; i++)
			System.out.println(i + " " + x(i) + " " + y(i));
		System.exit(0);
	}

	// Write your methods for x(i) and y(i) here
	public static int x(int i) {
		return 0; // Replace with correct return
	}
	public static int y(int i) {
		return 0; // Replace with correct return
	}
}