import javax.swing.*;

public class Sequence1 {
	public static void main(String[] args) {
		String input= JOptionPane.showInputDialog("Enter n");
		int n= Integer.parseInt(input);
		for (int i= 0; i <= n; i++) 
			System.out.println("i: "+ i + " q: " + q(i));
		System.exit(0);
	}
	
	public static double q(int n) {
		// Write your code here
		return 0;	// Replace this with correct return
	}
}