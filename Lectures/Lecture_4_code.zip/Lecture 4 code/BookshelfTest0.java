public class BookshelfTest0 {
	public static void main(String[] args) {
		double lengthLeft= 1.0;	// Remaining space on bookshelf
		int booksPlaced= 0;		// Books on shelf so far
		double length= 0.1;		// Length of book
		
		// Your code here: try to place items of length 0.1, 0.2,
		// 0.3, 0.4 and 0.5 on shelf. Loop while enough space
		
		System.out.println("Books placed: "+ booksPlaced);
		System.out.println("Length left: "+ lengthLeft);
	}		
}