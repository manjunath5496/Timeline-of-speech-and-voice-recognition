public class IntArithmetic {
	public static void main(String[] args) {
		int cubicInch = 2000 * 1000 * 1000;
		System.out.println("cubicInch: " + cubicInch);
		cubicInch += cubicInch;		// Add more space
		System.out.println("cubicInch: " + cubicInch);
	}
}