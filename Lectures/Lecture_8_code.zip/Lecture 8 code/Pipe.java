public class Pipe {
	private double radius;
	private double length;
	public Pipe(double r, double len) {
		radius = r;
		length = len;
	}
}