import javax.swing.*;

public class StudentTestWithInput {
	public static void main(String[] args) {
		Student[] team = new Student[3];
		for (int i= 0; i < team.length; i++) {
			String type = JOptionPane.showInputDialog("Enter student type");
			String fname = JOptionPane.showInputDialog("Enter student first name");
			String lname = JOptionPane.showInputDialog("Enter student last name");
			String payStr = JOptionPane.showInputDialog("Enter student pay");
			double pay= Double.parseDouble(payStr);
			if (type.equals("Grad"))
				team[i]= new Grad(fname, lname, pay);
			else if (type.equals("SpecGrad"))
				team[i]= new SpecGrad(fname, lname, pay);
			else
				team[i]= new Undergrad(fname, lname, pay, 8.0);
		}
		// Polymorphism, and late binding
		for (int i = 0; i < 3; i++) {
			System.out.print(team[i].getClass()+ ":   ");
			team[i].printData();
		}
	}
}