public class EngrComponent {
	private int ID;
	private static int nextID= 0;
	public EngrComponent() {
		ID= nextID++;
	}
	public final int getID() { return ID;}
}