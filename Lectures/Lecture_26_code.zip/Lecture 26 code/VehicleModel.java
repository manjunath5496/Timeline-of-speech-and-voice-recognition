public class VehicleModel {
	private int	width;
	private int	height;
	private int	vehicleX;
	private int	vehicleY;
	private double vehicleDir;
	private double speed= 0;
	private double speedF= 0.01;
	private int speedThreshold= 10;
	private double directionF= 0.0005;
	private int directionCtr= 500;
	private VehicleController sensors;

	public VehicleModel(VehicleController vs, int w, int h) {
		sensors= vs;
		width= w;
		height= h;
		vehicleX= width/2;
		vehicleY= height/2;
		vehicleDir= 0;
	}

	public void updateModel() {
		int p= sensors.getPressure();
		int r= sensors.getRotation();
		// Complete this method to update vehicle x, y, direction
		// when a sensor event occurs.
		// 1. Check if pressure sensor value above speedThreshold
		// 2. If so, set speed = pressure sensor * scale factor
		// 3. Set vehicle direction= rotation sensor * scale factor
		// 4. Update vehicle x, y coordinates: use sin(), cos()
		// 5. Check that vehicle stays within WIDTH, HEIGHT
	}

	public int getVehicleX() { return vehicleX; }
	public int getVehicleY() { return vehicleY; }
	public double getVehicleDir() { return vehicleDir; }
}