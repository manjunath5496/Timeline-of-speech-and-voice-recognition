public class StringExample {
	public static void main(String[] args) {
		String s= new String("Test");	// Strings are objects
		String first= "George ";		// Shortcut constructor
		String middle= "H.W. ";
		String last= "Bush";
		String full= first + middle + last;
		System.out.println("Full: " + full);

		// Testing for equality in strings (objects in general)
		String full2= "George H.W. Bush";
		if (full.equals(full2))     	// Right way
			System.out.println("Strings equal");
		if (full == full2)          	// Wrong way
			System.out.println("A miracle!");   
		if (first == "George ")     	// Wrong way, but sometimes works
			System.out.println("Not a miracle!"); // This is unreliable

		middle= middle.substring(2, 4) + " ";
		full= first + middle + last;
		System.out.println("Modified full: " + full);
	}
}
// We'll cover writing the equals() method in Objects under data structures