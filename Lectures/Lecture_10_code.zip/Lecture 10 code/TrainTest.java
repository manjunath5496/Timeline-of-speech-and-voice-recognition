public class TrainTest {		// Solution with one train, one engine
	public static void main(String[] args) {
		double vel= 30.0;						// 30 m/s, 70mph
		
		// Static method. No object needed.
		double f34= Engine.getForce(vel, 90000, 5500000);			

		// Engine
		Engine r34= new Engine(90000, 5500000);	// 90 tonnes, 5500 kW

		// Instance method
		double force34= r34.getForce(vel);
		
		// Don't need to create Cars. All we need is their mass
		// But we must set their mass: do it here. Set it to 50000 kg

		// Train
		Train amtrak41= new Train(r34, 10);
		// Instance method
		double force41= amtrak41.getNetForce(vel);

		System.out.println("At velocity: "+vel);
		System.out.println(" Engine force: "+ force34);
		System.out.println(" Net force: "+ force41);
		System.out.println(" Train resistance force: "+ (force34-force41));
	}
}