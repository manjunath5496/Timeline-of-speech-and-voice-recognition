public class ATM implements Runnable{
	private BankAccount ba;

	public ATM(BankAccount ba){
		this.ba = ba; 
	}

	public void run(){
		ba.deposit(100);  
	}

	public static void main(String[] args){ 
		int count= 0;
		BankAccount david = new BankAccount(500);
		for (int i= 0; i < 10000; i++) {
			david.total= 500.0;
			Thread you = new Thread(new ATM(david));
			Thread mother = new Thread(new ATM(david));
			you.start();
			mother.start();
			try {
				you.join();
				mother.join();
			} catch (Exception e) {
				System.out.println(e.getStackTrace());
			}
			if (i % 1000 == 0)
				System.out.println("i: " + i + " balance: " + david.total);
			if (david.total < 601.0) {
				count++;
				System.out.println("i: " + i + " balance: " + david.total);
			}
		}
		System.out.println("Number of incorrect account balances: " + count);
	}
}