public class BankAccount{
	double total = 0.0;
	public BankAccount(double total){  
		this.total = total;  
	}
	public void deposit( double money ){
		double temp = total + money;
		total = temp;
	}
}