import java.util.*;			// For exception

public interface Stack {
	public boolean isEmpty();
	public void push(Object o);
	public Object pop() throws EmptyStackException;
	public void clear();
}