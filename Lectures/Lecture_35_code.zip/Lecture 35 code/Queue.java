import java.util.*;

public interface Queue {
    public boolean isEmpty();
    public void add(Object o);
    public Object remove() throws NoSuchElementException;
    public void clear();
}