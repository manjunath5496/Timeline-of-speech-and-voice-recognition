import java.util.*;

public class RingQueue implements Queue {
    static public final int DEFAULT_CAPACITY= 8;
    private Object[] queue;
    private int front;
    private int rear;
    private int capacity;
    private int size = 0;

    public RingQueue(int cap) {
        capacity = cap;
        front = 0;
        rear = capacity - 1;
        queue= new Object[capacity];
    }
    
    public RingQueue() {
        this( DEFAULT_CAPACITY );
    }
    
    public void add(Object o) {
    	// Your code here
    }
    
    public Object remove() throws NoSuchElementException {
        if ( isEmpty() )
            throw new NoSuchElementException();
        else {
            // Your code here
        	return null;		// remove this
        }
    }
    
    public boolean isEmpty() {
    	// Your code here
    	return false;	// remove this
    }
    
    public void clear() {
    	// Your code here
    }
    
    private void grow() {
        Object[] old= queue;
        int oldCapacity= capacity;
        capacity *= 2;
        queue= new Object[capacity];
        if ( size == 0 )
            return;
        if ( front <= rear ) {
            System.arraycopy(old, front, queue, 0, size );
        } else if ( rear < front ) {
            int nFront= oldCapacity-front;
            System.arraycopy(old, front, queue, 0, nFront);
            System.arraycopy(old, 0, queue, nFront, size-nFront );
        }
        front= 0;
        rear= size-1;
    }
}