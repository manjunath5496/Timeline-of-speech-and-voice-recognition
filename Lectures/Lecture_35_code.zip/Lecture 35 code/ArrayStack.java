import java.util.*;

public class ArrayStack implements Stack {
	public static final int DEFAULT_CAPACITY = 8;
	private Object[] stack;
	private int top = -1;
	private int capacity;

	public ArrayStack(int cap) {
		capacity = cap;
		stack = new Object[capacity];
	}
	public ArrayStack() {
		this(DEFAULT_CAPACITY);
	}

	public boolean isEmpty() {
		// Complete this code
		return false;	// Just to prevent compile error. Remove this line.
	}

	public void clear() {
		// Complete this code
	}

	public void push(Object o) {
		// Complete this code
		// If stack is full already, call grow()
	}

	private void grow() {
		capacity *= 2;
		Object[] oldStack = stack;
		stack = new Object[capacity];
		System.arraycopy(oldStack, 0, stack, 0, top+1);
	}
	public Object pop() throws EmptyStackException {
		// Complete this code
		// If stack is empty, throw exception
		return null;		// Just to prevent compile error. Remove this line
		}
}