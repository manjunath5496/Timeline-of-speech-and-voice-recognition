public class MagSensor extends SensorReading {
	private static final long serialVersionUID = 1L;
	private double magRead;

	public MagSensor(String iD, int time, double reading, double magRead) {
		super(iD, time, reading);
		this.magRead = magRead;
	}

	public String toString() {
		return super.toString() + "\t\t" + magRead;
	}
}