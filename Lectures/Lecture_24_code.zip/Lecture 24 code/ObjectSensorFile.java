import java.io.*;

public class ObjectSensorFile {
	public static void main(String[] args) {
		SensorReading[] list= new SensorReading[5];
		list[0]= new SensorReading("S1", 1, 50.0);
		list[1]= new SensorReading("S22", 2, 70.0);
		list[2]= new SensorReading("S308", 4, 90.0);
		list[3]= new SensorReading("S4", 7, 0.0);
		list[4]= new MagSensor("M1", 10, 53.0, 24.0);
		try {
			FileOutputStream f= new FileOutputStream("sensorObject.dat");
			ObjectOutputStream out= new ObjectOutputStream(f);
			out.writeObject(list);
			out.close();
			
			FileInputStream fin= new FileInputStream("sensorObject.dat");
			ObjectInputStream in= new ObjectInputStream(fin);
			SensorReading[] newList= (SensorReading[]) in.readObject();
			in.close();
			
			for (int i=0; i < newList.length; i++)
				System.out.println(newList[i]);
				
		} catch(IOException e) {
			System.out.println(e);
		} catch(ClassNotFoundException e) {
			System.out.println(e);
		}
	}
}		// Doesn't use SensorReading get() and set() methods: what about security?