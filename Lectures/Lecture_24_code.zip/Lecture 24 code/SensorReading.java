import java.io.*;

public class SensorReading implements Serializable {
	private static final long serialVersionUID = 1L;
	private String ID;
	private int time;
	private double reading;
	
	public SensorReading() {}
	
	public SensorReading(String iD, int time, double reading) {
		ID = iD;
		this.time = time;
		this.reading = reading;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public double getReading() {
		return reading;
	}

	public void setReading(double reading) {
		this.reading = reading;
	}
	
	public String toString() {
		return (ID + "    \t" + time + "    \t" + reading);
	}
}