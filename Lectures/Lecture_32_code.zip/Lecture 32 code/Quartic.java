public class Quartic implements MathFunction {
	public double f(double x) {
		return x*x*x*x +2;
	}
}