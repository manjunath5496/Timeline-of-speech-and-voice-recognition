public class Tank {
	private double radius;
	private double length;
	private double thickness;

	public Tank(double r, double len, double t) {
		radius = r;
		length = len;
		thickness = t;
	}

	public double getMassCylinderWalls() {
		double mass= length*Math.PI*((radius + thickness)*(radius + thickness)- radius*radius);
		return mass;
	}
	
	public double getMassEnds() {
		double mass= 2.0*Math.PI*thickness*(radius + thickness)*(radius + thickness);
		return mass;
	}
	
	public double getMass() {
		return getMassCylinderWalls() + getMassEnds();
	}
}