// 1. What do you need to import to see Lake, River?

public class MapTest {
	public static void main(String[] args) {
		Mountain w= new Mountain("Washington", 6288);
		Mountain j= new Mountain("Jefferson", 5791);
		// 	2. Try to print out Mt Washington elevation, name
		//	Leave in what compiles, comment out what doesn�t

		//  Uncomment next two lines after you've written the import statement
		//	Lake winni=new Lake("Winnipesaukee", 44586);	// Acres
		//	River m= new River("Merrimack", 120, winni);

		//	3. Try to print size of Lake Winnipesaukee

		//	4. Is there another way to get the size?  Try it.
	}
}