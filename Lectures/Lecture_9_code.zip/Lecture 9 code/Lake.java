public class Lake {
	String name;			// Package access
	double area;			// Package access
	public Lake(String n, double a) {
		name= n;
		area= a;
	}
}